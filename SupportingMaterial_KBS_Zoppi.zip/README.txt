This ZIPfile contains data for building plots and tables in the paper.

Also, it contains the scripts used to generate such data, which are available also in the public github at

https://github.com/tommyippoz/FRAPPE

in the "exec" folder

