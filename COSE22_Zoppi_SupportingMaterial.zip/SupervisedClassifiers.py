# File for calculating scores of SUpervised classifiers for paper submission

import pandas as pd
import glob
import time
import sklearn.metrics as metrics

from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from xgboost import XGBClassifier

SCORES_FILENAME = "onehot.csv"
DATASETS_DIR = "onehot"
OUT_FOLDER = "onehot_unk"

LABEL_NAME = 'multilabel'
NORMAL_TAG = 'normal'
TRAIN_VALIDATION_SPLIT = 0.5

SKIP_FEATURES = ['timestamp']
SKIP_FEATURES_TAG = ['meta_', 'meta', "SUP_", "UNSUP_"]
SEPARATOR = ','


def read_dataset(csv_file):

    # Reading and Merging Dataset Files
    df = pd.read_csv(csv_file, sep=SEPARATOR)

    print("Features in Dataframe: " + str(len(df.columns)))

    # Removing features to skip
    for to_skip in SKIP_FEATURES:
        df = df.loc[:, ~df.columns.str.contains(to_skip)]

    # Removing features to skip
    for to_skip in SKIP_FEATURES_TAG:
        df = df.loc[:, ~df.columns.str.startswith(to_skip)]

    print("Features in Dataframe after removing specific ones: " + str(len(df.columns)))

    # Fill NaN
    df = df.fillna(0)

    # Removing constant columns
    df = df.loc[:, df.nunique() > 1]

    print("Features in Dataframe after removing constant ones: " + str(len(df.columns)))
    print(df.columns)

    # Partitioning Unified Dataset According to Label
    attacklabels = df[LABEL_NAME].unique()
    attacklabels = attacklabels[attacklabels != NORMAL_TAG]
    print("Dataset " + csv_file + ": Found " + str(len(attacklabels)) + " Attack Types")

    for label in attacklabels:
        partition = df.loc[df[LABEL_NAME] == label]
        print(label + ": " + str(len(partition.index)) + " attacks (" +
              "{:.3f}".format(100.0 * len(partition.index) / len(df.index)) + "%)")

    normalframe = df.loc[df[LABEL_NAME] == NORMAL_TAG]
    print("Normal data: " + str(len(normalframe.index)) + " items (" +
          "{:.3f}".format(100.0 * len(normalframe.index) / len(df.index)) + "%)")

    trainlist = []
    testlist = []

    # Normal Data
    splitIndex = int(len(normalframe) * TRAIN_VALIDATION_SPLIT)
    trainsample = normalframe[0: splitIndex]
    trainlist.append(trainsample)
    testsample = normalframe[splitIndex:]
    testlist.append(testsample)

    # Attack Data
    for label in attacklabels:
        partition = df.loc[df[LABEL_NAME] == label]
        partition = partition.sample(frac=1)
        splitIndex = int(len(partition) * TRAIN_VALIDATION_SPLIT)
        trainsample = partition[0: splitIndex]
        trainlist.append(trainsample)
        testsample = partition[splitIndex:]
        testlist.append(testsample)

    # Wrapping up train and test
    trainframe = pd.concat(trainlist)
    testframe = pd.concat(testlist)

    trainframe = trainframe.sample(frac=1.0)
    testframe = testframe.sample(frac=1.0)

    return trainframe, testframe, attacklabels


def normalizeArray(array):
    newArray = [True] * len(array)
    for i in range(0, len(array)):
        if array[i] == NORMAL_TAG:
            newArray[i] = False
        else:
            newArray[i] = True
    return newArray


def splitdataset(dataset):
    # Calculate Attack Rate
    normrows = len(dataset[dataset[LABEL_NAME] == NORMAL_TAG].index)
    allrows = len(dataset.index)
    attrate = (allrows - normrows) / allrows

    # Labels
    y = dataset.loc[:, dataset.columns.str.startswith(LABEL_NAME)]
    y = normalizeArray(y.to_numpy())

    # Data
    x = dataset.loc[:, ~dataset.columns.str.startswith(LABEL_NAME)]
    x = x.select_dtypes(exclude=['object'])
    x = x.to_numpy()

    return x, y, attrate


def available_classifiers():
    classList = []

    # Statistical
    classList.append(["Logistic Regression", LogisticRegression(random_state=0)])
    classList.append(["NaiveBayes", GaussianNB()])
    classList.append(["LDA", LinearDiscriminantAnalysis()])

    # XGBoost
    classList.append(["XGBoost Default", XGBClassifier()])
    classList.append(["XGBoost Squared", XGBClassifier(objective='reg:squarederror')])
    classList.append(["XGBoost Logistic", XGBClassifier(objective='binary:logistic')])
    classList.append(["XGBoost Hinge", XGBClassifier(objective='binary:hinge')])
    classList.append(["XGBoost Poisson", XGBClassifier(objective='count:poisson')])
    classList.append(["XGBoost NDCG Rank", XGBClassifier(objective='rank:ndcg')])

    # Gradient Boosting
    classList.append(["GradientBoosting 10/1",
                      GradientBoostingClassifier(n_estimators=10, learning_rate=1.0, random_state=0)])
    classList.append(["GradientBoosting 30/1",
                      GradientBoostingClassifier(n_estimators=30, learning_rate=1.0, random_state=0)])
    classList.append(["GradientBoosting 100/1",
                      GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, random_state=0)])
    classList.append(["GradientBoosting 10/.5",
                      GradientBoostingClassifier(n_estimators=10, learning_rate=0.5, random_state=0)])
    classList.append(["GradientBoosting 30/.5",
                      GradientBoostingClassifier(n_estimators=30, learning_rate=0.5, random_state=0)])
    classList.append(["GradientBoosting 100/.5",
                      GradientBoostingClassifier(n_estimators=100, learning_rate=0.5, random_state=0)])
    classList.append(["GradientBoosting 10/1/1",
                      GradientBoostingClassifier(n_estimators=10, learning_rate=1.0, max_depth=1, random_state=0)])
    classList.append(["GradientBoosting 30/1/1",
                      GradientBoostingClassifier(n_estimators=30, learning_rate=1.0, max_depth=1, random_state=0)])
    classList.append(["GradientBoosting 100/1/1",
                      GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=1, random_state=0)])
    classList.append(["GradientBoosting 10/1/5",
                      GradientBoostingClassifier(n_estimators=10, learning_rate=1.0, max_depth=5, random_state=0)])
    classList.append(["GradientBoosting 30/1/5",
                      GradientBoostingClassifier(n_estimators=30, learning_rate=1.0, max_depth=5, random_state=0)])
    classList.append(["GradientBoosting 100/1/5",
                      GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=5, random_state=0)])

    # SVM
    classList.append(["LinearSVM 10", BaggingClassifier(SVC(kernel='linear', probability=True, class_weight='balanced',
                                                            max_iter=10000), max_samples=1.0 / 5, n_estimators=5)])
    classList.append(
        ["QuadraticSVM 10", BaggingClassifier(SVC(kernel="poly", probability=True, class_weight='balanced', max_iter=10000),
                                              max_samples=1.0 / 5, n_estimators=5)])
    classList.append(["RBFSVM 10",
                      BaggingClassifier(SVC(gamma=2, probability=True, class_weight='balanced', max_iter=10000), max_samples=1.0 / 5,
                                        n_estimators=5)])
    # Random Forest
    classList.append(["RandomForest 10", RandomForestClassifier(n_estimators=10, random_state=0)])
    classList.append(["RandomForest 30", RandomForestClassifier(n_estimators=30, random_state=0)])
    classList.append(["RandomForest 100", RandomForestClassifier(n_estimators=100, random_state=0)])
    classList.append(["RandomForest 10 / 10", RandomForestClassifier(max_depth=10, n_estimators=10, random_state=0)])
    classList.append(["RandomForest 30 / 10", RandomForestClassifier(max_depth=10, n_estimators=30, random_state=0)])
    classList.append(["RandomForest 100 / 10", RandomForestClassifier(max_depth=10, n_estimators=100, random_state=0)])

    # kNN
    classList.append(["kNN 1", KNeighborsClassifier(1)])
    classList.append(["kNN 3", KNeighborsClassifier(3)])
    classList.append(["kNN 10", KNeighborsClassifier(10)])
    classList.append(["kNN 30", KNeighborsClassifier(30)])
    classList.append(["kNN 100", KNeighborsClassifier(100)])

    # Decision Tree
    classList.append(["Decision Tree 5", DecisionTreeClassifier(max_depth=5)])
    classList.append(["Decision Tree 20", DecisionTreeClassifier(max_depth=20)])
    classList.append(["Decision Tree", DecisionTreeClassifier()])

    # Boosting
    classList.append(["ADABoost 10", AdaBoostClassifier(n_estimators=10)])
    classList.append(["ADABoost 30", AdaBoostClassifier(n_estimators=30)])
    classList.append(["ADABoost 100", AdaBoostClassifier(n_estimators=100)])
    classList.append(["ADABoost 200", AdaBoostClassifier(n_estimators=200)])

    # Neural Network
    classList.append(["MLP Network", MLPClassifier(alpha=1, max_iter=500)])

    return classList


def scoreunknowns(test, atttags, y_pred):
    tp = 0
    fn = 0
    i = 0
    for index in test.index:
        if test.at[index, LABEL_NAME] in atttags:
            if y_pred[i]:
                tp = tp + 1
            else:
                fn = fn + 1
        i = i + 1
    return tp, fn


def score_classifier(dataset_name, exptag, classifier_name, classifier, x_train, y_train, x_test,
                     y_test, train_att_rate, test_att_rate,  n_unknowns, excluded_attacks):
    print("Initializing and Fitting " + classifier_name + " with " + str(len(y_train)) + " train and " +
          str(len(y_test)) + " test instances (" + str(len(x_train[0])) + " features, " + str(train_att_rate * 100) +
          "% of attacks in train set)")

    start = time.time()
    classifier.fit(x_train, y_train)
    elapsedTrain = time.time() - start
    start = time.time()
    y_pred = classifier.predict(x_test)
    elapsedTest = time.time() - start

    if n_unknowns > 0:
        tpunk, fnunk = scoreunknowns(test, excluded_attacks, y_pred)
    else:
        tpunk = 0
        fnunk = 0

    # Scoring Confusion Matrix
    tn, fp, fn, tp = metrics.confusion_matrix(y_test, y_pred).ravel()
    accuracy = metrics.accuracy_score(y_test, y_pred)
    mcc = abs(metrics.matthews_corrcoef(y_test, y_pred))
    if accuracy < 0.5:
        accuracy = 1.0 - accuracy
        tp, fn = fn, tp
        tn, fp = fp, tn

    print("TP: " + str(tp) + ", TN: " + str(tn) + ", FP: " + str(fp) + ", FN: " + str(fn) + ", Accuracy: " + str(
        accuracy) + ", MCC: " + str(mcc))

    # Write file
    with open(SCORES_FILENAME, "a") as myfile:
        # Print DatasetInfo
        myfile.write(dataset_name + "," + exptag + "," + classifier_name + "," +
                     str(len(y_train)) + "," + str(len(y_test)) + "," + str(len(x_train[0])) + "," +
                     str(train_att_rate) + "," + str(test_att_rate) + "," +
                     str(elapsedTrain) + "," + str(elapsedTest) + ",")
        # Print Scores
        myfile.write(str(tp) + "," + str(tn) + "," + str(fp) + "," + str(fn) + "," + str(accuracy) +
                     "," + str(mcc) + "," + str(tpunk) + "," + str(fnunk) + "\n")


def data_analysis(train, test, dataset_name, exp_tag, n_unknowns, excluded_attacks):

    print(dataset_name + "[" + exp_tag + "]: Complete Dataset")

    # Separating labels from data
    x_train, y_train, train_att_rate = splitdataset(train)
    x_test, y_test, test_att_rate = splitdataset(test)

    # Building Classifier
    for classifierItem in available_classifiers():
        classifierName = classifierItem[0]
        classifier = classifierItem[1]
        score_classifier(dataset_name, exp_tag, classifierName, classifier,
                         x_train, y_train, x_test, y_test, train_att_rate, test_att_rate, n_unknowns, excluded_attacks)


if __name__ == '__main__':

    # Setup Output File
    with open(SCORES_FILENAME, "w") as myfile:
        # Print Header
        myfile.write("datasetName,experimentTag,classifierName,trainItems,testItems,features,trainAttRate,testAttRate" +
                     ",elapsedTimeTrain,elapsedTimeTest,tp,tn,fp,fn,accuracy,mcc,tpunk,fnunk\n")

    for csv_file in glob.glob(DATASETS_DIR + "/*.csv"):
        train, test, attack_labels = read_dataset(csv_file)

        if "/" in csv_file:
            csv_file = csv_file.split("/")[-1]

        filename = OUT_FOLDER + "/" + csv_file
        train.to_csv(filename + "_FULL_TRAIN.csv", index=False)
        test.to_csv(filename + "_TEST.csv", index=False)

        # Analysis on Full Dataset
        data_analysis(train, test, csv_file, "Full", 0, [])

        if len(attack_labels) > 1:

            for attack_name in attack_labels:
                # Analysis on Dataset trained with all attacks but attackName
                label_analysis = "_NO(" + attack_name + ")_"
                train_no_att = train.loc[train[LABEL_NAME] != attack_name]
                train_no_att.to_csv(filename + label_analysis + "_TRAIN.csv", index=False)

                n_unknowns = len(test[test[LABEL_NAME] == attack_name].index)
                data_analysis(train_no_att, test, csv_file, label_analysis, n_unknowns, [attack_name])
