import pandas as pd
from collections import Counter
from sklearn.preprocessing import LabelEncoder
from collections import Counter
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from fastai.vision import *
import numpy as np
from sklearn.metrics import *
from sklearn.metrics import ConfusionMatrixDisplay
from fastai import *
from fastai.tabular import *
from fastai.callbacks import *
from utils import *
import time


"""
Execute the implemented Fastai model over datasets listed in dataset_list.csv. The parameter used for the execution are readed, for each dataset, from the 'dataset_list.csv' file. The output is written in the fastai_results.csv file.
"""

dataset_list = pd.read_csv('./dataset_list.csv')

print(dataset_list)

count = 0

output = pd.DataFrame()

data = dataset_list['File'], dataset_list['Type'], dataset_list['Categoriche'], dataset_list['Validation'], dataset_list['LR'], dataset_list['WD'], dataset_list['Test'], dataset_list['Attack'], dataset_list['Epoch']

for j in range(len(data[0])):

	train_path = '../dataset/'+ data[1][j] + '/' + data[0][j]
	test_path = '../dataset/'+ data[1][j] + '/' + data[6][j]

	print(train_path)
	print(test_path)

	full_train = pd.read_csv(train_path)
	full_test = pd.read_csv(test_path)

	full_train = full_train.drop('label', axis=1,  errors='ignore')
	full_train = full_train.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('label', axis=1,  errors='ignore')
	full_test = full_test.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')
	full_train = full_train.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')

	dep_var = 'multilabel'

	test = full_test.copy()
	test['multilabel'] = test['multilabel'].apply(lambda x: to_binary(x))

	train = full_train.copy()
	train['multilabel'] = train['multilabel'].apply(lambda x: to_binary(x))

	print(train)
	print(test)

	#LabelEncoder of the categorical variables listed, for each dataset, in the 'dataset_list.csv' file

	cat_names = data[2][j].split(',')		

	if(cat_names[0]==''):
		cat_names = []

	print(cat_names)	

	for col in cat_names:

		le = LabelEncoder()
		final = pd.concat([train[col],test[col]])
		final = final.drop_duplicates()
		le.fit(final)

		train.loc[:, col] = le.transform(train[col])
		test.loc[:, col] = le.transform(test[col])

	#LabelEncoder of the multilabel column. The obtained values are memorized in the y_test and y_train vectors
    #y_test is used for the final model evaluation.

	y_train = train[dep_var]	
	y_train.replace(to_replace="unexpected", value=1, inplace=True)
	y_train.replace(to_replace="normal", value=0, inplace=True)

	y_test = test[dep_var]
	y_test.replace(to_replace="unexpected", value=1, inplace=True)
	y_test.replace(to_replace="normal", value=0, inplace=True)	
	test = test.drop(dep_var, axis=1)

	print(train.head())
	print(test.head())

	cont_names = [col for col in train.columns if col not in cat_names and col != dep_var]
	procs = [FillMissing, Categorify, Normalize]
	val = data[3][j]

	#Split the training set in to train and validation set

	traindf, idx = SplitSet(train, float(val))

	#Create a list used for final prediction over the test set

	test = TabularList.from_df(test, cat_names= cat_names, cont_names=cont_names, procs=procs)

	print(cat_names)
	print(cont_names)

    #Create a list containing train and validation set 

	dat = TabularList.from_df(traindf, cat_names= cat_names, cont_names=cont_names, procs=procs)
	dat = dat.split_by_idx(list(range(idx, len(traindf))))
	dat = dat.label_from_df(cols=dep_var)
	dat = dat.add_test(test, label= 0)
	dat = dat.databunch()  
	
    #Create the neural network model

	learn = tabular_learner(dat, layers=[200, 100], metrics=accuracy, emb_drop=0.01)

	start = time.time()

    #Model's training
  	
	learn.fit_one_cycle(data[8][j], data[4][j], wd= data[5][j])	#

	end = time.time()
	
	start_pred = time.time()

	#Prediction over the test set.

	pred, *_ = learn.get_preds(DatasetType.Test)
	label = np.argmax(pred, 1)

	end_pred = time.time()

	y_pred = np.array(label)

	#Model's evaluation
	
	output = EvaluateModelSplit(data[0][j], data[7][j],full_train, full_test, y_test, y_pred, count, output, 'Fastai', data[4][j], end-start, end_pred-start_pred)
	
	output.at[count,"Epoch"] = data[8][j]
	output.at[count,"WD"] = data[5][j]

	count = count + 1

	output.to_csv('./fastai_results.csv', index=False)