from pytorch_tabnet.tab_model import TabNetClassifier, TabNetRegressor
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import numpy as np
from utils import * 
import time


"""
Execute the implemented Tabnet model over datasets listed in dataset_list.csv. The output is written in the tabnet_results.csv file.
"""

dataset_list = pd.read_csv('./dataset_list.csv')

count = 0

output = pd.DataFrame()

print(dataset_list)

data = dataset_list['File'], dataset_list['Type'], dataset_list['Categoriche'], dataset_list['Validation'], dataset_list['Test'], dataset_list['Attack'] 

for j in range(len(data[0])):

	train_path = '../dataset/'+ data[1][j] + '/' + data[0][j]
	test_path = '../dataset/'+ data[1][j] + '/' + data[4][j]

	print(test_path)
	print(train_path)

	full_train = pd.read_csv(train_path)
	full_test = pd.read_csv(test_path)

	full_train = full_train.drop('label', axis=1,  errors='ignore')
	full_train = full_train.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('label', axis=1,  errors='ignore')
	full_test = full_test.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')
	full_train = full_train.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')

	print(full_test)
	
	dep_var = 'multilabel'

	test = full_test.copy()
	test['multilabel'] = test['multilabel'].apply(lambda x: to_binary(x))

	train = full_train.copy()
	train['multilabel'] = train['multilabel'].apply(lambda x: to_binary(x))

	print(train)
	print(test)

	#LabelEncoder of the categorical variables listed, for each dataset, in the 'dataset_list.csv' file

	cat_names = data[2][j].split(',')		

	if(cat_names[0]==''):
		cat_names = []

	print(cat_names)	

	for col in cat_names:

		le = LabelEncoder()
		final = pd.concat([train[col],test[col]])
		final = final.drop_duplicates()
		le.fit(final)

		train.loc[:, col] = le.transform(train[col])
		test.loc[:, col] = le.transform(test[col])

	#LabelEncoder of the multilabel column. The obtained values are memorized in the y_test and y_train vectors
    #y_test is used for the final model evaluation.
    	
	y_train = train[dep_var]	
	y_train.replace(to_replace="unexpected", value=1, inplace=True)
	y_train.replace(to_replace="normal", value=0, inplace=True)
	train = train.drop(dep_var, axis=1)

	y_test = test[dep_var]
	y_test.replace(to_replace="unexpected", value=1, inplace=True)
	y_test.replace(to_replace="normal", value=0, inplace=True)	
	test = test.drop(dep_var, axis=1)
	
	#Split the training set into train and validation set

	train, validation, y_train, y_val = train_test_split(train, y_train, test_size=data[3][j])

	y_train = y_train.values
	y_test = y_test.values
	y_val = y_val.values

	train = train.to_numpy()
	test = test.to_numpy()
	validation = validation.to_numpy()

	clf = TabNetClassifier()
	
	start = time.time()

	#Model's training
	
	try:
		clf.fit(train, y_train, eval_set = [(validation,y_val)])
	except ValueError:
		pass

	end = time.time()

	start_predict = time.time()

	#Prediction over the test set. 

	preds = clf.predict(test)

	end_predict = time.time()

	y_pred = preds.astype(int)

	#Model's evaluation

	output = EvaluateModelSplit(data[0][j], data[5][j], full_train, full_test, y_test, y_pred, count, output, 'Tabnet', 'NaN', end-start, end_predict-start_predict)

	count = count + 1

	output.to_csv('./tabnet_results.csv', index=False)