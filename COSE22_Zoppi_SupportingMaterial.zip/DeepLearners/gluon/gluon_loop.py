import pandas as pd
from collections import Counter
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pprint
import random
from autogluon.tabular import TabularPredictor
import mxnet as mx
from autogluon.tabular import TabularPredictor
from sklearn.metrics import *
from utils import *
import time

"""
Execute the implemented Autogluon model over datasets listed in dataset_list.csv file. The output is written in the autogluon_results.csv file.
"""
dataset_list = pd.read_csv('./dataset_list.csv')

count = 0

output = pd.DataFrame()

print(dataset_list)

data = dataset_list['File'], dataset_list['Test'], dataset_list['Type'],dataset_list['Attack']

for i in range(len(data[0])):   

    train_path ='../dataset/'+ data[2][i] + '/' + data[0][i]
    test_path ='../dataset/'+ data[2][i] + '/' + data[1][i] 

    print(test_path)
    print(train_path)

    full_train = pd.read_csv(train_path)
    full_test = pd.read_csv(test_path)

    full_train = full_train.drop('label', axis=1,  errors='ignore')
    full_train = full_train.drop('binlabel', axis=1,  errors='ignore')
    full_test = full_test.drop('label', axis=1,  errors='ignore')
    full_test = full_test.drop('binlabel', axis=1,  errors='ignore')
    full_test = full_test.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')
    full_train = full_train.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')

    test = full_test.copy()
    test['multilabel'] = test['multilabel'].apply(lambda x: to_binary(x))

    train = full_train.copy()
    train['multilabel'] = train['multilabel'].apply(lambda x: to_binary(x))

    print(train)
    print(test)

    dep_var = 'multilabel'

    # LabelEncoder of the multilabel column. The obtained values are memorized in the y_test and y_train vectors
    # y_test is used for the final model evaluation.

    y_train = train[dep_var]    
    y_train.replace(to_replace="unexpected", value=1, inplace=True)
    y_train.replace(to_replace="normal", value=0, inplace=True)

    y_test = test[dep_var]
    y_test.replace(to_replace="unexpected", value=1, inplace=True)
    y_test.replace(to_replace="normal", value=0, inplace=True)  
    test = test.drop(dep_var, axis=1)

    print(test)
    print(train)

    print('Number of training samples:', len(train))
    print('Number of test samples:', len(test))

    start = time.time()

    predictor = TabularPredictor(label=dep_var) #problem_type='binary'

    #Model's training

    predictor.fit(train, hyperparameters='multimodal')

    models = predictor.get_model_names()

    print(models)
    
    nn_name = models[4]
    end = time.time()

    start_predict = time.time()

    #Prediction over the test set

    y_pred = predictor.predict(test, model=nn_name)

    end_predict = time.time()

    y_pred = y_pred.to_numpy()
    y_test = y_test.T

    print(type(y_pred))
    print(type(y_test))

    count_test = []
    for j in y_test:
        count_test.append(j)

    count_pred = []
    for j in y_pred:
        count_pred.append(j)
        
    print('Test:', Counter(count_test))
    print('Pred:', Counter(count_pred))

    #Model's evaluation

    output = EvaluateModelSplit(data[0][i], data[3][i], full_train, full_test, y_test, y_pred, count, output, 'Autogluon', 'NaN', end-start, end_predict-start_predict)

    count = count + 1

    output.to_csv('./autogluon_results', index=False)
    



