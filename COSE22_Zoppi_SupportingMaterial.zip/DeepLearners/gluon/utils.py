import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import torch
from torch.utils.data import Dataset, DataLoader
import torch.optim as torch_optim
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from sklearn.model_selection import train_test_split
from sklearn.metrics import *


def EvaluateModelSplit(name, atk_name, train, test, y_test, y_pred, index, output, class_name, lr, time, time_predict):
	

	if(atk_name!='normal'):
		exper = '_NO('+atk_name+')_'
	else:
		exper = 'Full Dataset'

	train_row = train.shape[0]
	test_row = test.shape[0]
	test_col = test.shape[1]-1

	train_nonormal = train[train['multilabel'] != 'normal'] 

	print(train)
	print(train_nonormal)
	print(train_nonormal.shape[0])
	print(train.shape[0])
	print(test)

	train_atk = (train[train['multilabel'] != 'normal'].shape[0] * 100)/ train.shape[0]
	test_atk = (test[test['multilabel'] != 'normal'].shape[0] * 100)/ test.shape[0]

	print('Test:', Counter(y_test))
	print('Pred:', Counter(y_pred))
	
	cm = confusion_matrix(y_test, y_pred)
	report = classification_report(y_test, y_pred)
	acc = accuracy_score(y_test, y_pred)
	mcc = matthews_corrcoef(y_test, y_pred)
	recall = recall_score(y_test, y_pred, average='weighted')
	precision = precision_score(y_test, y_pred, average='weighted')
	# non presente nella libreria, calcolo mediante formula
	f2 = (1+2**2)*((precision*recall)/((2**2*precision)+recall))

	print(cm)

	TN = cm[0,0]
	TP = cm[1,1]
	FP = cm[0,1]
	FN = cm[1,0]

	print('True positive: ', TP)
	print('True negative: ', TN)
	print('False positive: ', FP)
	print('False negative: ', FN)
	print('Accuracy: ', acc)
	print('Precision_weighted: ', precision)
	print('Recall_weighted: ', recall)
	print('mcc: ', mcc)
	print('f2: ', f2)


	output.at[index,"Dataset"] = name
	output.at[index,"Experiment"] = exper
	output.at[index,"Classifier"] = class_name 
	output.at[index,"Train Items"] = train_row
	output.at[index,"Test Items"] = test_row
	output.at[index,"Features"] = test_col
	output.at[index,"Train Atk Rate"] = train_atk
	output.at[index,"Test Atk Rate"] = test_atk
	output.at[index,"Accuracy"] = acc
	output.at[index,"mcc"] = mcc
	output.at[index,"TP"] = TP
	output.at[index,"TN"] = TN
	output.at[index,"FP"] = FP
	output.at[index,"FN"] = FN
	output.at[index,"LR"] = lr

	if(atk_name != 'normal'):

		x = np.arange(test.shape[0])
		test = test.set_index(x)

		print(test)
		print(len(Counter(test['multilabel'])))
		no_seen_idx = test.index[test['multilabel'] == atk_name].tolist()

		y_test_noseen = y_test[no_seen_idx]
		y_pred_noseen = y_pred[no_seen_idx]

		print(y_test_noseen)
		print(y_pred_noseen)
		print(len(y_pred_noseen))
		print(len(y_test_noseen))

		cm_noseen = confusion_matrix(y_test_noseen, y_pred_noseen)
		print(cm_noseen)

		fn_noseen = 0
		tp_noseen = 0	
		if(len(Counter(y_pred_noseen))!=1):
			tp_noseen = cm_noseen[1,1]
			fn_noseen = cm_noseen[1,0]
		else:
			if(y_pred_noseen[0]==1):
				tp_noseen = cm_noseen[0]
			else:
				tp_noseen = cm_noseen[1,1]
				fn_noseen = cm_noseen[1,0]

		output.at[index,"TP-Unk"] = tp_noseen
		output.at[index,"FN-Unk"] = fn_noseen	
	output.at[index,"Time_train"] = time
	output.at[index,"Time_predict"] = time_predict	

	return output

def to_binary(x):   
    
    if(x != 'normal'):
        x = 'unexpected'
    else:
    	x = 'normal'
    return x	

def SplitSet(df, valid):
	
	train, valid = train_test_split(df, test_size=valid)
	split_val = len(train)
	train = train.append(valid)
	return train, split_val    