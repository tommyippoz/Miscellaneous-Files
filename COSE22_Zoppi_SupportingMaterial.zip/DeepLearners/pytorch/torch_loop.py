import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import torch
from torch.utils.data import Dataset, DataLoader
import torch.optim as torch_optim
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from sklearn.model_selection import train_test_split
from sklearn.metrics import *
from utils  import *
import time


"""
Execute the implemented Fastai model over datasets listed in dataset_list.csv. The parameter used for the execution are readed, for each dataset, from the 'dataset_list.csv' file. The output is written in the fastai_results.csv file.
"""

dataset_list = pd.read_csv('./dataset_list.csv')

print(dataset_list)

output = pd.DataFrame()

data = dataset_list['File'], dataset_list['Type'], dataset_list['Categoriche'], dataset_list['Validation'], dataset_list['LR'], dataset_list['WD'], dataset_list['Test'], dataset_list['Attack'], dataset_list['Epoch'] 

count = 0

for j in range(len(data[0])):

	train_path = '../dataset/'+ data[1][j] + '/' + data[0][j]
	test_path = '../dataset/'+ data[1][j] + '/' + data[6][j]

	print(test_path)
	print(train_path)

	full_train = pd.read_csv(train_path)
	full_test = pd.read_csv(test_path)

	full_train = full_train.drop('label', axis=1,  errors='ignore')
	full_train = full_train.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('label', axis=1,  errors='ignore')
	full_test = full_test.drop('binlabel', axis=1,  errors='ignore')
	full_test = full_test.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')
	full_train = full_train.drop('MEAN_RR_MEAN_MEAN_REL_RR', axis=1,  errors='ignore')

	dep_var = 'multilabel'

	test = full_test.copy()
	test['multilabel'] = test['multilabel'].apply(lambda x: to_binary(x))

	train = full_train.copy()
	train['multilabel'] = train['multilabel'].apply(lambda x: to_binary(x))

	print(train)
	print(test)

	#LabelEncoder of the categorical variables listed, for each dataset, in the 'dataset_list.csv' file

	cat_names = data[2][j].split(',')		

	if(cat_names[0]==''):
		cat_names = []

	print(cat_names)	

	for col in cat_names:

		le = LabelEncoder()
		final = pd.concat([train[col],test[col]])
		final = final.drop_duplicates()
		le.fit(final)

		train.loc[:, col] = le.transform(train[col])
		test.loc[:, col] = le.transform(test[col])

	cont_names = [col for col in train.columns if col != dep_var]

	#LabelEncoder of the multilabel column. The obtained values are memorized in the y_test and y_train vectors
    #y_test is used for the final model evaluation.

	y_train = train[dep_var]	
	y_train.replace(to_replace="unexpected", value=1, inplace=True)
	y_train.replace(to_replace="normal", value=0, inplace=True)
	train = train.drop(dep_var, axis=1)

	y_test = test[dep_var]
	y_test.replace(to_replace="unexpected", value=1, inplace=True)
	y_test.replace(to_replace="normal", value=0, inplace=True)	
	test = test.drop(dep_var, axis=1)

	#Split the training set into train and validation set

	train, validation, y_train, y_val = train_test_split(train, y_train, test_size=data[3][j])

	y_train = y_train.values
	y_test = y_test.values
	y_val = y_val.values


	""" Pytorch Dataset e DataLoader
	Extend Pytorch's abstract dataset class for easier access to data and effective use of the DataLoader module. This results in overriding the __len__ and __getitem__ methods 
	""" 

	class TorDataset(Dataset):
		def __init__(self, X, Y):
			X = X.copy()
			self.X = X.copy().values.astype(np.float32)
			self.y = Y

		def __len__(self):
			return len(self.y)

		def __getitem__(self, idx):
			return self.X[idx], self.y[idx]

		        
	#Creating train and validation set
	
	train_ds = TorDataset(train, y_train)
	valid_ds = TorDataset(validation, y_val)

	""" Making device (GPU/CPU) compatible (borrowed from https://jovian.ml/aakashns/04-feedforward-nn)
	In order to make use of a GPU if available, we'll have to move our data and model to it. """ 

	def get_default_device():
	   """Pick GPU if available, else CPU"""
	   if torch.cuda.is_available():
	   		return torch.device('cuda')
	   else:
	       return torch.device('cpu')

	def to_device(data, device):

		"""Move tensor(s) to chosen device"""

		if isinstance(data, (list,tuple)):
		    return [to_device(x, device) for x in data]
		return data.to(device, non_blocking=True)

	class DeviceDataLoader():

		"""Wrap a dataloader to move data to a device"""

		def __init__(self, dl, device):
		    self.dl = dl
		    self.device = device
		        
		def __iter__(self):

		    """Yield a batch of data after moving it to device"""

		    for b in self.dl: 
		        yield to_device(b, self.device)

		def __len__(self):

		    """Number of batches"""
		    
		    return len(self.dl)

	device = get_default_device()

	class TorModel(nn.Module):

		def __init__(self, n_cont):

		    super().__init__()
		    self.n_cont =  n_cont
		    self.lin1 = nn.Linear(self.n_cont, 200)
		    self.lin2 = nn.Linear(200, 100)
		    self.lin3 = nn.Linear(100, 2)
		    self.bn1 = nn.BatchNorm1d(self.n_cont, momentum=1.0)
		    self.bn2 = nn.BatchNorm1d(200, momentum=1.0)
		    self.bn3 = nn.BatchNorm1d(100, momentum=1.0)
	        
		def forward(self, x_cont):

		    x = self.bn1(x_cont)
		    x = F.relu(self.lin1(x))
		    #x = self.drops(x)
		    x = self.bn2(x)
		    x = F.relu(self.lin2(x))
		    #x = self.drops(x)
		    x = self.bn3(x)
		    x = self.lin3(x)

		    return x

	#Define the model Optimizer

	def get_optimizer(model, lr, wd=0):
		parameters = filter(lambda p: p.requires_grad, model.parameters())
		optim = torch_optim.Adam(parameters, lr=lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, amsgrad=False)
		return optim

	#Define the training model

	def train_model(model, optim, train_dl):

		model.train()
		total = 0
		sum_loss = 0
		for x, y in train_dl:
		    batch = y.shape[0]
		    output = model(x)
		    loss = F.cross_entropy(output, y)   
		    optim.zero_grad()
		    loss.backward()
		    optim.step()
		    total += batch
		    sum_loss += batch*(loss.item())

		return sum_loss/total

	#Define the evaluation function

	def val_loss(model, valid_dl):
		
		model.eval()
		total = 0
		sum_loss = 0
		correct = 0
		for x, y in valid_dl:
		    current_batch_size = y.shape[0]
		    out = model(x)
		    loss = F.cross_entropy(out, y)
		    sum_loss += current_batch_size*(loss.item())
		    total += current_batch_size
		    pred = torch.max(out, 1)[1]
		    correct += (pred == y).float().sum().item()

		print('valid loss ', sum_loss/total, ' and accuracy ', correct/total)

		return sum_loss/total, correct/total
	    	

	#Define the training loop

	def train_loop(model, epochs, lr, wd): 
		
		optim = get_optimizer(model, lr=lr, wd=wd)
		    
		for i in range(epochs): 
		    loss = train_model(model, optim, train_dl)
		    print('ep ', i, "training loss: ", loss)
		    val_loss(model, valid_dl)
		
	batch_size = 512
	train_dl = DataLoader(train_ds, batch_size=batch_size,shuffle=True)
	valid_dl = DataLoader(valid_ds, batch_size=batch_size,shuffle=True)

	train_dl = DeviceDataLoader(train_dl, device)
	valid_dl = DeviceDataLoader(valid_dl, device)

	model = TorModel(len(cont_names))

	to_device(model, device)
	
	start = time.time()

	#Model's training

	train_loop(model, epochs=data[8][j], lr=data[4][j], wd=data[5][j]) 

	end = time.time()

	start_pred = time.time()

	test_ds = TorDataset(test, np.zeros(len(test)))
	test_dl = DataLoader(test_ds, batch_size=batch_size)
	test_dl = DeviceDataLoader(test_dl, device)

	#Prediction over the test set. Softmax function used to calculate probabilities for the two classes

	preds = []
	with torch.no_grad():
		for x,y in test_dl:
		    out = model(x)
		    prob = F.softmax(out, dim=1)
		    preds.append(prob)

	y_pred = []
	for i in range(0, len(preds)):
		pred = preds[i].cpu()
		temp = np.argmax(pred, 1)
		temp = np.array(temp)
		y_pred = np.append(y_pred, temp)

	y_pred = y_pred.astype(int)

	end_pred = time.time()

	#Model's evaluation

	output = EvaluateModelSplit(data[0][j], data[7][j],full_train, full_test, y_test, y_pred, count, output, 'Pytorch (NoCatEmbedding)', data[4][j], end-start, end_pred-start_pred)
	
	output.at[count,"Epoch"] = data[8][j]
	output.at[count,"WD"] = data[5][j]
	
	count = count + 1

	output.to_csv('./torch_results.csv', index=False)

