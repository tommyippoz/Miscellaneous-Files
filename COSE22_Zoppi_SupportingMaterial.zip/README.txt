Archive containing support files for submission

"Who can Detect Unknown Attacks? Comparison of Supervised, Unsupervised and Meta-Learning Algorithms for Intrusion Detection"

to Elsevier COSE

Contains:
- excel file with all source data to generate tables and figures in the paper
- folder containing Python scripts to execute deep learners and supervised classifiers
- unsupervised classifiers were exercised by means of a public tool (RELOAD) already referenced in the paper.

We do not own datasets and thus we cannot redistribute them. References to datasets are in the paper.